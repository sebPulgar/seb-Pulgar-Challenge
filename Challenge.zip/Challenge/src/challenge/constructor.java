package challenge;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class constructor{
        int datos;
        int cantDatos;
        int nMayor;
        ArrayList numeros = new ArrayList();
        ArrayList registro = new ArrayList();
        int valor;
        Scanner scan = new Scanner(System.in);
        
    public void generarNum(){  
       //Se pide al usuario la cantidad de datos que se quieren generar 
       Scanner reader = new Scanner (System.in);
       System.out.println("Ingrese la cantidad de datos que desea generar: "); 
       cantDatos = reader.nextInt();
       System.out.println("Ingrese el dato mas grande ");
       nMayor = reader.nextInt();
       
       for (int i = 1; i <= cantDatos; i++){
            datos = (int) (Math.random() * nMayor + 1);
            if (numeros.contains(datos)){
                i--;
            }
            else{
                numeros.add(datos);
                registro.add(datos);
            }    
        }        
        System.out.println("Los Numeros se han Generado con exito\n");       
    }
    
    public void mostrarNum(){
        //Imprime los numeros que se guardaron en la ArrayList
        for (Object n : numeros) 
        {
            System.out.println(n + "");  
        }
    }
    public void ordenar(){
        //Ordena los numeros
        Collections.sort(registro);
        System.out.println("Los Numeros se han ordenado con exito\n");  
    }
    public void mostrarNumO(){
        //Imprime los numeros ordenados que se encuentran en la ArrayList
        for (Object n : registro){
            System.out.println(n + "");  
        }
    }
    
    public void buscarNum(){
        //Realiza una busqueda en la Arraylist
        System.out.println("Ingrese que numero desea buscar");
        valor = scan.nextInt();
        if(registro.contains(valor)){
            System.out.println("El numero se encuentra en el archivo");
        }
        else{
            System.out.println("El numero no se encuentra en el archivo");
        }
    }   
}